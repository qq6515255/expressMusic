<template lang="html">
  <div class="navFooter">
    <div class="container">
      Copyright © 2017 个人网站 All Rights Reserved 粤ICP备17128307号-1
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="less" scoped>
  .navFooter{
    height: 80px;
    line-height: 80px;
    background-color: #24292e;
    text-align: center;
    color: #fff;
    font-size: 12px;
  }
</style>
